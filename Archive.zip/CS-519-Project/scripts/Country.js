class Country {
  constructor(id, name, lat, lon, cases, death, recovered) {
    this.id = id;
    this.name = name;
    this.lat = lat;
    this.lon = lon;
    this.cases = cases;
    this.death = death;
    this.recovered = recovered;
  }
}
